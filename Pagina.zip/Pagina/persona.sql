CREATE TABLE Persona (
cedula int PRIMARY KEY,
nombre VARCHAR(20),
apellido VARCHAR(20),
telefono VARCHAR(15),
correo VARCHAR(30)
);



insert into Persona values (123,'Diego','Perez','456132','a@a.com');
insert into Persona values (456,'Juan','Montoya','456132','b@a.com');
insert into Persona values (789,'Pedro','Ramirez','456132','c@a.com');
insert into Persona values (147,'Alvaro','Perez','456132','d@a.com');

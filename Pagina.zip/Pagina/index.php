<html>
	<head>
		<title>Agenda de Personas</title>
		<meta charset="utf-8"> 
	</head>
	<body>
		<center>
		<table>
			<tr>
				<td><a href="consultar.php">Consultar Personas</a></td>
			</tr>
			<tr>
				<td><a href="agregar.html">Agregar Personas</a></td>
			</tr>
			<tr>
				<td><a href="eliminar.html">Borrar Personas</a></td>
			</tr>
			<tr>
				<td><a href="actualizar.html">Actualizar Personas</a></td>
			</tr>

		</table>
		</center>
	</body>
</html>

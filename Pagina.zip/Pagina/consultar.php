<html>
	<head>
		<meta charset="utf-8"> 
		<title>Agenda de Personas :: Consultar Personas</title>
	</head>
	<body>
		<?php
			/*ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(E_ALL);*/
			function mostrarDatos ($resultados) {
				if ($resultados !=NULL) {
					echo "<tr><td>".$resultados['cedula']."</td>";
					echo "<td>".$resultados['nombre']."</td>";
					echo "<td>".$resultados['apellido']."</td>";
					echo "<td>".$resultados['telefono']."</td>";
					echo "<td>".$resultados['correo']."</td></tr>";
				}
				else {
					echo "<br/>No hay m�s datos!!! <br/>";
				}
			}
			$servername = "192.168.0.22";
			$database = "distribuidos";
			$username = "carlos";
			$password = "31000208a";

			$link = mysqli_connect($servername, $username, $password, $database, 3306) or die('Error de conexion' . mysqli_connect_error());
			if (link){
				$tildes = $link->query("SET NAMES 'utf8'");
				$result = mysqli_query($link, "SELECT * FROM Persona");
				echo"<center> <table border=1 align='center'>" ;	
				while ($fila = mysqli_fetch_array($result)){
				mostrarDatos($fila);
				}
				echo"</table></center>";
			} else {
				die("Connection failed: " . mysqli_connect_error());
			}

				
			mysqli_free_result($result);
			mysqli_close($link);
		?>
	</body>
</html>

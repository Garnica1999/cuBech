<html>
	<head>
		<meta charset="utf-8"> 
		<title>Actualizar Agenda</title>
	</head>
	<body>
		<?php
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(E_ALL);
			$servername = "192.168.0.22";
			$database = "distribuidos";
			$username = "carlos";
			$password = "31000208a";
			$link = mysqli_connect($servername, $username, $password, $database, 3306) or die('Error de conexion' . mysqli_connect_error());
			$tildes = $link->query("SET NAMES 'utf8'");
			$cedula= $_POST['cedula'];
			$nombre= $_POST['nombre'];
			$apellido= $_POST['apellido'];
			$telefono= $_POST['telefono'];
			$correo= $_POST['correo'];

			$query = "UPDATE Persona SET nombre='$nombre', apellido='$apellido', telefono='$telefono', correo='$correo' WHERE cedula=$cedula;";
			
			$result = mysqli_query($link,$query);
			if(!$result){
				echo 'No se pudo actualizar el dato correctamente. Verifique la cedula'
			} else {
				echo 'Se ha actulizado el registro correctamente'
			}
			mysqli_free_result($result);
			mysqli_close($link);
			
		?>

	</body>
</html>
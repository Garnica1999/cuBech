
<html>
	<head>
		<meta charset="utf-8"> 
		<title>Agenda de Personas :: Consultar Personas</title>
	</head>
	<body>
		<?php
			$servername = "192.168.0.22";
			$database = "distribuidos";
			$username = "carlos";
			$password = "31000208a";

			$link = mysqli_connect($servername, $username, $password, $database, 3306) or die('Error de conexion' . mysqli_connect_error());
			$tildes = $link->query("SET NAMES 'utf8'");
			$id = $_POST['eliminado']; 
			$result = mysqli_query($link, " DELETE FROM Persona WHERE cedula =".$id);
			if(!$result) {
			echo 'No se ha eliminado el registro';
			} else {
			echo 'El registro se ha eliminado satisfactoriamente';
			}
			mysqli_free_result($result);
			mysqli_close($link);
		?>
	</body>
</html>




